'use strict'

const DynamoTable = require('./services/dynamo')

const gamesTable = new DynamoTable(process.env.GAMES_TABLE)

exports.handler = async (event, context, callback) => {
  const games = await gamesTable.scan()
  const response = {
    statusCode: 200,
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
    },
    body: games
  }
  callback(null, response)
}
